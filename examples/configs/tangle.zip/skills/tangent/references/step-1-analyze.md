# Step 1: Analyze

Choose the highest-ROI experiment direction based on evidence.

## Round 1: Launch Researcher

**Skip research if** `research-brief.md` already exists in `$SCENARIO_DIR` (from a prior
session or the scenario builder). Read the existing brief and proceed to "Every Round."

Otherwise, **launch the researcher as a subagent using the Agent tool.** Do not just
read the file — you must actually invoke it as a foreground agent and wait for completion.
Skip only if user says "skip research" or `scenario.research.enabled` is explicitly `false`.

Spawn the researcher via `spawn_subagent template: researcher`, passing this
task context as its task:

```
---
Task context:
Research the <scenario_name> pipeline.
Scenario: <scenario.research section>
Baseline run_id: <baseline_run_id>
Parent run_id: <prior round's best_run_id, or "n/a — round 1">
Code paths: <code_paths>
Image roots: <image_roots>
Write brief to: <SCENARIO_DIR>/research-brief.md
Write priors to: <SCENARIO_DIR>/research-priors.txt
```

The `parent_run_id` is the round's _active run_id_ for upload keying — see the
researcher brief template. Round 1: no parent → key by `baseline_run_id`.

**If the researcher agent fails or times out**, do NOT block the experiment loop. Log
the failure, then fall back to the experiment types in `scenario.experiment_actions` and
MEMORY.md priors. Research is high-value but not blocking.

Then read `research-brief.md`. Your experiment choice MUST follow the top-ranked
research direction. Only fall back to generic parameter tuning if research
recommends it or all directions have been tried.

## Round 2+

Read Step 5 analysis findings from the previous round (session log / MEMORY.md).
The Direction Proposal tells you what to try next based on the data.

## Every Round

1. Read MEMORY.md — best config, budget, lessons
2. Read `scenario.yaml` for available experiment types
3. Use free analysis actions before expensive experiments

## Choosing Experiment Type

Choose the TYPE, not just the parameter:

| Experiment Type        | Typical ROI | When to Use                                   |
| ---------------------- | ----------- | --------------------------------------------- |
| Analysis (free)        | Information | Always first                                  |
| Feature selection      | High        | Dead features or feature dominance            |
| Data actions           | High        | Noisy labels or train/eval misalignment       |
| Parameter tuning       | Medium-High | LR, capacity, regularization — first 2 rounds |
| Pipeline modifications | Medium      | Pipeline topology is the bottleneck           |

## Upload research brief to GCS

After the researcher writes `research-brief.md`, upload it to the learnings corpus.
Key by the **active run_id** — for Round 1 that's `baseline_run_id`; for round 2+
re-research that's the prior round's `best_run_id` (the parent run that motivated
the new research pass).

```bash
# Round 1: active_run_id == baseline_run_id
# Round 2+: active_run_id == prior round's best_run_id
gcloud storage cp \
  "$SCENARIO_DIR/research-brief.md" \
  "gs://shopify-discovery-relevance/tangent/learnings/<scenario>/research-<active_run_id>.md"
```

If the upload fails, log a `learning_upload_failed` event and keep going — local is
the source of truth. See `references/knowledge-corpus.md` for the bucket layout.

## Gate — do NOT proceed to Step 2 until all pass:

- [ ] Round 1: **`research-brief.md` exists at `$SCENARIO_DIR/research-brief.md`** (verify with Read — if missing, researcher did not run)
- [ ] Research brief uploaded to `gs://shopify-discovery-relevance/tangent/learnings/<scenario>/research-<active_run_id>.md` (Round 1: keyed by `baseline_run_id`; Round 2+: keyed by prior round's `best_run_id`) — or `learning_upload_failed` event logged
- [ ] Round 2+: Step 5 Direction Proposal from previous round has been read
- [ ] MEMORY.md reviewed for budget and lessons
- [ ] Experiment direction chosen with **Phase A evidence** (not anchored on Phase B FYI context)
- [ ] `step_transition` event logged
- [ ] **Reload + review**: re-read this step file and `.tangent/agents/researcher.md`; agent confirms it remembers them
